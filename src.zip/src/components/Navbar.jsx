import { useState } from 'react';
import './Navbar.css';

function Navbar() {
  // State to toggle mobile menu
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <nav className="navbar">
      <div className="navbar-container">
        {/* Logo */}
        <div className="navbar-logo">
          <span className="logo-icon">🎬</span>
          <span className="logo-text">CineBook</span>
        </div>

        {/* Mobile menu button */}
        <button
          className="menu-toggle"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          ☰
        </button>

        {/* Navigation links */}
        <ul className={`nav-links ${isMenuOpen ? 'active' : ''}`}>
          <li><a href="#home">Home</a></li>
          <li><a href="#movies">Movies</a></li>
          <li><a href="#popular">Popular</a></li>
          <li><a href="#login" className="login-btn">Login</a></li>
        </ul>
      </div>
    </nav>
  );
}

export default Navbar;
